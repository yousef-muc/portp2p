# Self-Hosting

`portp2p` can run its own rendezvous and relay infrastructure. Official builds
default to `https://portp2p.com`, but a self-hosted URL supplied through
`--server`, `PORTP2P_SERVER`, a JSON configuration file, or the local Web UI
always takes precedence.

## Roles

`portp2p` has three infrastructure modes:

- `portp2p rendezvous`: HTTP control plane only.
- `portp2p relay`: libp2p Circuit Relay v2 only.
- `portp2p server`: combined rendezvous plus relay in one process.

For most deployments, start with the combined server.

`portp2p web` is not an infrastructure role or server administration console.
It is a loopback-only client interface on an individual user's machine. Start
it with `--server https://relay.example.com`, or set the rendezvous URL in its
local Server dialog before creating sessions. Share and Connect forms also
accept an explicit relay multiaddr when automatic server discovery should be
overridden. Never expose the Web UI through the public reverse proxy.

The rendezvous HTTP listener defaults to `127.0.0.1:8080` and does not
terminate TLS. Public deployments must place it behind an HTTPS reverse proxy
or explicitly bind it to a protected internal network.

## Combined Server

```sh
portp2p server --plain \
  --listen 0.0.0.0:8080 \
  --p2p-listen /ip4/0.0.0.0/tcp/4001 \
  --advertise-relay /dns4/relay.example.com/tcp/4001/p2p/<relay-peer-id> \
  --identity /var/lib/portp2p/identity.key
```

Open the HTTP port used by `--listen` and the libp2p TCP port used by
`--p2p-listen`.

Clients then use:

```sh
portp2p share 3000 --plain --server http://SERVER_HOST:8080
portp2p connect <code> --plain --server http://SERVER_HOST:8080
```

### Discovery And Access

The same rendezvous process can hold opt-in public listings. Normal shares are
never listed. A sharer must select `--publish`, and searchers use the same
server URL:

```sh
portp2p share 3000 --plain \
  --server http://SERVER_HOST:8080 \
  --publish --name "Demo service" --category demo --tag http

portp2p discover demo --plain --server http://SERVER_HOST:8080
```

Listings are held in memory and tied to live shares. No database, account, or
role system is required. A running sharer republishes its listing after a
rendezvous restart without changing its public code or original expiry.
Servers also advertise signed Discovery v2 support. Clients can opt into a
stable, cryptographically signed service identity with `--service-key`; the
server verifies it against the peer that owns the live share. No persistent
server storage is required for these proofs.

Signed services may use `--access approval` so public search exposes metadata
but no connect code. They may also use `--visibility private` to stay out of
public search and require a random invitation. Private and approval modes
require `--service-key`. Access requests and approved grants are temporary,
bounded in-memory state; they add no account, role, or database requirement.
See [Discovery and controlled access](discovery.md) for the complete flow.

An operator can additionally mark known signed publishers as verified:

```sh
portp2p status --plain

portp2p server --plain \
  --discovery-verified-publisher 12D3KooW... \
  --discovery-verified-publisher 12D3KooX...
```

Only valid libp2p Peer IDs are accepted. The setting is an in-memory startup
allowlist, not an account or role database. A `verified` result means that the
current discovery-server operator placed that signed Publisher ID on its
allowlist; it is not a global endorsement by portp2p. Remove an ID and restart
the server to revoke the operator verification.

`share` automatically fetches the current relay addresses from `GET /v1/info`
and reserves the first reachable relay. This lets the operator change relays
without publishing new client builds. `--advertise-relay` is optional for local
use, but public deployments should set it to a stable, externally reachable
DNS or IP multiaddr.

To override discovery explicitly, pass a relay to `share`:

```sh
portp2p share 3000 --plain \
  --server http://SERVER_HOST:8080 \
  --relay /ip4/SERVER_IP/tcp/4001/p2p/<relay-peer-id>
```

The connector can force the relay path for verification:

```sh
portp2p connect <code> --plain \
  --server http://SERVER_HOST:8080 \
  --relay-only
```

## Split Rendezvous And Relay

Run rendezvous:

```sh
portp2p rendezvous --plain \
  --listen 0.0.0.0:8080 \
  --advertise-relay /dns4/relay.example.com/tcp/4001/p2p/<relay-peer-id> \
  --identity /var/lib/portp2p/rendezvous.key
```

Run relay:

```sh
portp2p relay --plain \
  --p2p-listen /ip4/0.0.0.0/tcp/4001 \
  --identity /var/lib/portp2p/relay.key
```

Configure the relay address on the rendezvous process with
`--advertise-relay`. Clients then discover it automatically; `share --relay`
remains an explicit override.

## Recommended Limits

Rendezvous limits:

```sh
portp2p server --plain \
  --listen 0.0.0.0:8080 \
  --p2p-listen /ip4/0.0.0.0/tcp/4001 \
  --rate-limit-requests 120 \
  --rate-limit-window 1m \
  --max-control-bytes 65536 \
  --max-sessions 10000 \
  --max-sessions-per-remote 16 \
  --max-addrs-per-share 32 \
  --max-discovery-listings 1000 \
  --max-discovery-listings-per-remote 4 \
  --max-access-requests 5000 \
  --max-access-requests-per-listing 32 \
  --max-access-requests-per-remote 16 \
  --access-request-ttl 15m \
  --access-grant-ttl 10m
```

Relay limits:

```sh
portp2p server --plain \
  --listen 0.0.0.0:8080 \
  --p2p-listen /ip4/0.0.0.0/tcp/4001 \
  --relay-profile public-small
```

The opt-in `public-small` profile currently expands to:

| Limit | Value |
| --- | ---: |
| Connection duration | 30 minutes |
| Data per connection and direction | 128 MiB |
| Active reservations | 32 |
| Circuits per peer | 2 |
| Active circuits globally | 24 |
| Global transfer budget | 20 GiB per 24 hours |
| Admission requests | 4 per peer, 8 per IP, 120 globally per hour |
| Relay buffer | 8 KiB |
| Reservations | 1 per peer, 4 per IP, 16 per ASN |

The profile is selected only by the operator. Every explicit `--relay-*` flag
overrides its corresponding profile value; omitting `--relay-profile` preserves
the normal self-hosting defaults.

Adjust these values for your traffic. Public infrastructure should use explicit
limits, metrics scraping, and alerting. `--relay-max-circuits` applies per peer;
`--relay-max-active-circuits` applies across the entire relay process and is
disabled when set to `0`. The global transfer budget counts bytes in both
directions across all circuits. Once exhausted, existing circuits continue
under their individual limits, new circuits are refused, and admission resumes
when the configured window resets. The counter is held in memory, so restarting
the relay begins a fresh window. A byte budget of `0` disables this limit.
Admission limits count circuit requests that reach the relay policy and apply
atomically per peer ID, source IP, and globally. Each dimension can be disabled
with `0`; the counters reset with their window or a relay restart.

Clients receive actionable errors when capacity, admission policy, a missing
reservation, or an unreachable destination prevents relay use. In JSON mode,
these conditions are reported as `relay_capacity`, `relay_policy_denied`,
`relay_destination_unavailable`, or `relay_connection_failed`.

The production defaults already cap rendezvous at 10,000 active sessions and
16 sessions per source address. Set either value to `0` only when an external
system provides an equivalent limit.

Discovery separately defaults to 1,000 active listings and 4 listings per
source address. Public and private listings both count toward these limits.
Both values are operator-configurable and may be disabled with `0` for larger
self-hosted environments that provide equivalent external controls. Discovery
also shares the control-plane request rate and body limits.

The Access v3 control plane separately defaults to 5,000 active requests and
grants, 32 per listing, and 16 per source address. Pending requests expire
after at most 15 minutes and approved grants after at most 10 minutes; both are
also capped by the listing's remaining lifetime. Count limits can be disabled
with `0` for appropriately protected self-hosted deployments. Expiry remains
mandatory so abandoned requests and grants cannot accumulate indefinitely.

The defaults permit 24-hour connections and 10 GiB per direction so browser
applications, large downloads, and long-lived WebSockets are not cut off by
the much smaller upstream Circuit Relay defaults. Relay reservations remain
one hour but are refreshed automatically by a running `share` process.
The share also refreshes its rendezvous registration without extending the
original share expiry, allowing active shares to recover after a rendezvous
process restart.

For users behind HTTP proxies or restrictive firewalls, expose the relay over
WSS on port 443 in addition to native TCP. See
[Proxy And WebSocket Operation](proxies-and-websockets.md).
When the reverse proxy runs on the same host, pass
`--trusted-proxy 127.0.0.1`; add other proxy IPs or CIDRs only when they are
under your control.

## Health, Readiness, And Metrics

The rendezvous HTTP service exposes:

```sh
curl http://SERVER_HOST:8080/healthz
curl http://SERVER_HOST:8080/readyz
curl http://SERVER_HOST:8080/metrics
curl http://SERVER_HOST:8080/v1/info
curl http://SERVER_HOST:8080/v1/discovery
```

Use `/healthz` for basic liveness, `/readyz` to inspect effective limits, and
`/metrics` for Prometheus-compatible operational metrics. `/v1/info` returns
the current relay discovery configuration used by `share`.
`/v1/discovery` returns current public service listings.

## Identity

Use `--identity` for stable Peer IDs:

```sh
portp2p server --identity /var/lib/portp2p/identity.key
```

The identity file is created with private-file permissions. Back it up if you
want the same relay Peer ID after moving hosts.

```sh
portp2p --identity /var/lib/portp2p/identity.key identity init
portp2p --identity /var/lib/portp2p/identity.key identity backup /secure/portp2p-server.key
```

On the replacement host, restore the backup before starting the server. Restore
refuses to replace a key that already exists.

## Configuration

Configuration precedence is:

1. CLI flags
2. Environment variables
3. JSON config file from `--config` or `PORTP2P_CONFIG`
4. Build-time defaults

Example:

```json
{
  "server_url": "http://SERVER_HOST:8080",
  "log_level": "info",
  "identity_path": "/var/lib/portp2p/identity.key",
  "proxy_url": "http://proxy.example.com:3128"
}
```

Environment variables:

```sh
PORTP2P_SERVER=http://SERVER_HOST:8080
PORTP2P_LOG_LEVEL=info
PORTP2P_IDENTITY=/var/lib/portp2p/identity.key
PORTP2P_PROXY=http://proxy.example.com:3128
PORTP2P_CONFIG=/etc/portp2p/config.json
```
