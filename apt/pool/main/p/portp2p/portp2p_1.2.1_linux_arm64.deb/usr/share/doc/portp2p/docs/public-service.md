# Public Service

Official builds use `https://portp2p.com` as their default rendezvous and
discovery service. The service publishes its current native and WSS relay
addresses through `GET /v1/info`, so relay hosts, ports, transports, and Peer
IDs can change without rebuilding clients.

The default does not publish a share. Normal shares remain private and require
the random share code; discovery still requires an explicit `--publish`.
Self-hosting remains supported, and every custom server setting takes
precedence over the official default:

1. CLI flag: `--server`
2. Environment: `PORTP2P_SERVER`
3. JSON config file from `--config` or `PORTP2P_CONFIG`
4. Build default: `https://portp2p.com`

The public service uses the same binary as self-hosted deployments. Its public
relay multiaddrs are configured with `server --advertise-relay`; `share` uses
server discovery automatically unless the user supplies `--relay`.

For a small public host, explicitly enable the hardened runtime baseline:

```sh
portp2p server --plain \
  --listen 127.0.0.1:8080 \
  --trusted-proxy 127.0.0.1 \
  --p2p-listen /ip4/0.0.0.0/tcp/4001 \
  --advertise-relay /dns4/relay.example.com/tcp/4001/p2p/<relay-peer-id> \
  --relay-profile public-small \
  --max-discovery-listings 1000 \
  --max-discovery-listings-per-remote 4 \
  --max-access-requests 5000 \
  --max-access-requests-per-listing 32 \
  --max-access-requests-per-remote 16 \
  --access-request-ttl 15m \
  --access-grant-ttl 10m \
  --identity /var/lib/portp2p/identity.key
```

`public-small` is an operator-selected profile, not a hostname-dependent mode.
It limits each circuit to 30 minutes and 128 MiB per direction, allows 32
reservations, 2 circuits per peer and 24 circuits globally, and admits at most
4 requests per peer, 8 per source IP, and 120 globally per hour. The process
also stops admitting new circuits after 20 GiB in a 24-hour window. Existing
circuits retain their individual limits, while rendezvous and direct P2P remain
available.

Public service discovery remains opt-in for sharers. Public and private
listings both count toward the configured limits. Access requests and grants
have separate count and expiry limits. The server applies the existing
control-plane rate limits and removes discovery state with its underlying
share. Listing state is held in memory and running sharers restore it after a
service restart; pending requests and grants deliberately do not persist.

Explicit `--relay-*` flags override individual profile values. Omitting the
profile keeps the normal self-hosting defaults. No database, user account, or
role system is required; budget and admission counters are held in memory.
