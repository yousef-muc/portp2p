# Manual QA Checklist

Run this checklist before a release tag. It intentionally describes manual
checks instead of automated test files.

Use fresh terminals for long-running commands. Stop long-running `portp2p`
processes with Ctrl+C after each scenario.

## Baseline

From the private source repository:

```sh
go test ./...
rg --files -g '*_test.go'
go run ./cmd/portp2p version --plain
go run ./cmd/portp2p version --json
go run ./cmd/portp2p status --plain
go run ./cmd/portp2p status --json
```

Expected:

- `go test ./...` compiles all packages and reports `[no test files]`.
- `rg --files -g '*_test.go'` prints nothing.
- `version` includes version, commit, date, Go version, OS/arch, default server
  URL, and user agent.
- `status` includes server, log level, identity path, and control retry settings.

## Local Direct Tunnel

Terminal A:

```sh
go run ./cmd/portp2p rendezvous --plain --listen 127.0.0.1:18080
```

Terminal B:

```sh
python3 -m http.server 3000 --bind 127.0.0.1
```

Terminal C:

```sh
go run ./cmd/portp2p share 3000 --plain \
  --server http://127.0.0.1:18080 \
  --p2p-listen /ip4/127.0.0.1/tcp/0
```

Copy the printed code.

Terminal D:

```sh
go run ./cmd/portp2p connect <code> --plain \
  --server http://127.0.0.1:18080 \
  --port 9000 \
  --p2p-listen /ip4/127.0.0.1/tcp/0
```

Terminal E:

```sh
curl -I http://127.0.0.1:9000/
```

Expected:

- `share` prints a code, Peer ID, direct loopback addresses, and
  `Waiting for libp2p connections`.
- `connect` prints `Connection: DIRECT` and `Forwarding: 127.0.0.1:9000 ->`.
- `curl` returns HTTP `200`.

## Relay-Only Tunnel

Terminal A:

```sh
go run ./cmd/portp2p relay --plain --p2p-listen /ip4/127.0.0.1/tcp/0
```

Copy one printed `Relay addr`.

Terminal B:

```sh
go run ./cmd/portp2p rendezvous --plain --listen 127.0.0.1:18081
```

Terminal C:

```sh
python3 -m http.server 3000 --bind 127.0.0.1
```

Terminal D:

```sh
go run ./cmd/portp2p share 3000 --plain \
  --server http://127.0.0.1:18081 \
  --p2p-listen /ip4/127.0.0.1/tcp/0 \
  --relay <relay-addr>
```

Copy the printed code.

Terminal E:

```sh
go run ./cmd/portp2p connect <code> --plain \
  --server http://127.0.0.1:18081 \
  --port 9001 \
  --p2p-listen /ip4/127.0.0.1/tcp/0 \
  --relay-only
```

Terminal F:

```sh
curl -I http://127.0.0.1:9001/
```

Expected:

- `share` prints a relay reservation and a `/p2p-circuit` address.
- `connect` prints `Connection: RELAY`, `Dial path: RELAY`, and a remote
  `/p2p-circuit` address.
- `curl` returns HTTP `200`.

## Direct-First With Relay Fallback

Repeat the relay-only setup, but run `connect` without `--relay-only`:

```sh
go run ./cmd/portp2p connect <code> --plain \
  --server http://127.0.0.1:18081 \
  --port 9002 \
  --p2p-listen /ip4/127.0.0.1/tcp/0
```

Expected:

- On local loopback, direct dialing may succeed first.
- If direct dialing fails in a real network, relay fallback should still connect.
- The output always shows the chosen `Connection` and `Dial path`.

## JSON Output And Errors

```sh
go run ./cmd/portp2p version --json
go run ./cmd/portp2p status --json
go run ./cmd/portp2p connect not-a-uuid --json
go run ./cmd/portp2p connect not-a-uuid --plain
```

Expected:

- JSON success output is valid JSON.
- JSON error output contains `type: error`, `code`, `message`, and `command`.
- Plain error output starts with `Error:`.
- `go run` may append `exit status 1`; a built binary should not.

## Config And Identity

Create a temporary config:

```sh
mkdir -p /tmp/portp2p-qa
cat > /tmp/portp2p-qa/config.json <<'EOF'
{
  "server_url": "http://127.0.0.1:18100",
  "log_level": "debug",
  "identity_path": "/tmp/portp2p-qa/identity.key"
}
EOF
```

Run:

```sh
go run ./cmd/portp2p --config /tmp/portp2p-qa/config.json status --plain
PORTP2P_SERVER=http://127.0.0.1:18101 go run ./cmd/portp2p --config /tmp/portp2p-qa/config.json status --json
go run ./cmd/portp2p --identity /tmp/portp2p-qa/identity.key relay --plain --p2p-listen /ip4/127.0.0.1/tcp/0
```

Stop and run the same relay command again.

Expected:

- `status` uses config values.
- `PORTP2P_SERVER` overrides the config server.
- The identity file is created with private-file permissions.
- Re-running with the same identity path keeps the same Peer ID.

## Lifecycle And Limits

Preflight failure:

```sh
go run ./cmd/portp2p rendezvous --plain --listen 127.0.0.1:18082
go run ./cmd/portp2p share 39999 --plain --server http://127.0.0.1:18082
curl http://127.0.0.1:18082/healthz
```

Expected:

- `share` fails before registration because no target listens on port `39999`.
- `/healthz` reports `active_sessions: 0`.

Local port conflict:

```sh
python3 -m http.server 9003 --bind 127.0.0.1
go run ./cmd/portp2p connect <valid-code> --plain \
  --server http://127.0.0.1:18080 \
  --port 9003
```

Expected:

- `connect` fails before opening the libp2p tunnel because the local port is in
  use.

Stream limit:

```sh
go run ./cmd/portp2p share 3000 --plain \
  --server http://127.0.0.1:18080 \
  --p2p-listen /ip4/127.0.0.1/tcp/0 \
  --max-tunnel-streams 1
```

Expected:

- Output shows `Max tunnel streams: 1`.
- One normal forwarded `curl` request succeeds.

## Rendezvous Hardening

```sh
go run ./cmd/portp2p rendezvous --plain \
  --listen 127.0.0.1:18083 \
  --rate-limit-requests 3 \
  --rate-limit-window 1m \
  --max-control-bytes 1024 \
  --max-sessions 1 \
  --max-sessions-per-remote 1 \
  --max-addrs-per-share 4
curl http://127.0.0.1:18083/readyz
curl http://127.0.0.1:18083/metrics
```

Expected:

- `/readyz` shows the configured limits.
- `/metrics` returns Prometheus text with rendezvous counters and active
  sessions.

## Release Snapshot

Run a local non-publishing release snapshot. If `GPG_KEY_PATH` is not already set
to a local signing key, create a short-lived throwaway key for the snapshot:

```sh
tmpgnupg="$(mktemp -d /tmp/portp2p-gnupg.XXXXXX)"
chmod 700 "$tmpgnupg"
keyfile="/tmp/portp2p-snapshot-signing-key.asc"
GNUPGHOME="$tmpgnupg" gpg --batch --pinentry-mode loopback --passphrase '' --quick-gen-key 'portp2p snapshot <release@portp2p.local>' rsa2048 sign 1d
GNUPGHOME="$tmpgnupg" gpg --batch --armor --export-secret-keys 'portp2p snapshot <release@portp2p.local>' > "$keyfile"
export GPG_KEY_PATH="$keyfile"

goreleaser release --snapshot --clean --skip=publish
(cd dist && shasum -a 256 -c checksums.txt)
ruby -c dist/homebrew/portp2p.rb
./dist/portp2p_darwin_arm64_v8.0/portp2p version --plain
```

Expected:

- GoReleaser creates macOS/Linux tarballs, Windows zip archives, `.deb`, `.rpm`,
  `checksums.txt`, and `dist/homebrew/portp2p.rb`.
- Checksums verify.
- Homebrew formula syntax is OK.
- Snapshot binary shows injected version, commit, date, and user agent.

The tagged GitHub release workflow gets its signing key from
`LINUX_REPO_GPG_PRIVATE_KEY`; the throwaway key above is only for local snapshot
QA.
