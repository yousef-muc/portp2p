# portp2p Product 1.0

`portp2p` 1.0 is intended to be a robust, self-hostable P2P port forwarding product, not a permanently reduced prototype.

Required product scope:

- `portp2p share <port>` for exactly one TCP service on `127.0.0.1:<port>`.
- `portp2p connect <uuid> [--port <local-port>]` for a local listener on the connector side.
- Rendezvous metadata includes the shared target port so `connect <uuid>` can default to the same local port.
- A single binary for client, rendezvous, and relay roles.
- Build-time version metadata for release artifacts and support diagnostics.
- `portp2p server` for self-hosted rendezvous plus relay.
- UUIDv4 share capabilities with short TTLs.
- Persistent local libp2p identity for stable Peer IDs across restarts.
- Rendezvous sessions stored only in memory for product 1.0.
- Rendezvous control plane over a small JSON HTTP/WebSocket API.
- Bounded retries and timeouts for transient rendezvous control-plane failures.
- Rendezvous control requests identify the client version with a stable `User-Agent`.
- Rendezvous health/readiness endpoints and configurable control-plane rate limits.
- Rendezvous active-session, per-remote session, and per-share address limits.
- Rendezvous operational metrics for active sessions, control-plane traffic, limit denials, and cleanup.
- go-libp2p as the internal networking backend.
- libp2p encrypted streams for data plane traffic.
- Connector-side libp2p dialing from resolved rendezvous peer metadata.
- Tunnel streams using `/portp2p/tunnel/1.0.0`.
- TCP forwarding where connector-side local connections open one libp2p stream each.
- Share target preflight before registration and connector listener preflight before dialing.
- Capability proof on each tunnel stream before the share side opens the target port.
- Share-side capability nonce replay protection for tunnel streams.
- Share-side concurrent tunnel stream limits.
- Explicit share closing and rendezvous cleanup on shutdown or TTL expiry.
- libp2p Circuit Relay v2 as a first-class fallback path.
- Self-hosted Circuit Relay v2 service in `portp2p relay` and `portp2p server`.
- Configurable Circuit Relay resource limits for self-hosted relay/server modes.
- Share-side Circuit Relay v2 reservations and relayed addrs in rendezvous.
- Connector-side relay-only dialing for explicit relay path verification.
- Connector-side direct-first dialing with relay fallback when direct dialing fails.
- Connector-side dial address validation and prioritization for predictable path selection.
- Rendezvous propagation of reachability and transport capability metadata.
- AutoNATv2 and libp2p Hole Punching enabled on client hosts.
- AutoNAT service support enabled on relay/server hosts.
- Direct connections preferred when possible, relay used when needed.
- TUI for interactive terminals and plain/JSON output for automation.
- Consistent machine-readable JSON errors for automation and concise plain stderr errors for humans.
- Installation, self-hosting, and security documentation for first-release users.
- Manual release QA runbook covering direct, relay, config, lifecycle, hardening, and packaging checks.

Deferred until after release/build readiness:

- Environment-proven NAT behavior across many real networks.
- DCUtR hole punching validation and direct upgrade tuning.

Out of scope for 1.0:

- User accounts.
- Persistent service bridges.
- Web dashboard.
- Access to arbitrary target hosts, machines, subnets, filesystems, or multiple ports.
- Custom NAT traversal research separate from libp2p.
- A custom relay stack separate from libp2p Circuit Relay v2.
