# Release and Packaging

`portp2p` releases should ship one binary:

- `portp2p`

The private source repository can stay private. Tagged releases publish binaries,
checksums, Linux packages, Homebrew formula updates, and Linux package
repositories to the public distribution repository:

```text
https://github.com/yousef-muc/portp2p
```

## Public Distribution Repository Docs

The source-controlled templates for the public repository are:

```text
docs/public-repo/README.md
docs/public-repo/AGENTS.md
```

Sync them into the local public repository checkout before a release:

```sh
scripts/release/sync-public-repo-docs.sh
```

The script defaults to `/Users/yousef/Developer/Misc/portp2p`. Override the
destination when the public repository is checked out elsewhere:

```sh
PUBLIC_REPO_DIR=/path/to/portp2p scripts/release/sync-public-repo-docs.sh
```

Review the public repository diff and commit it there separately. The sync does
not commit, push, tag, or publish anything.

## One-Time GitHub Setup

Before the first tag release:

1. Commit and push the source repository, including `.goreleaser.yml`, the
   release workflow, and release scripts.
2. Commit and push the synced `README.md` and `AGENTS.md` in the public
   `yousef-muc/portp2p` repository.
3. Confirm that `yousef-muc/homebrew-tap` exists and accepts formula updates.
4. Add `HOMEBREW_TAP_GITHUB_TOKEN` to the private source repository's Actions
   secrets. It must have contents write access to `yousef-muc/portp2p` and
   `yousef-muc/homebrew-tap`.
5. Add the armored private signing key as `LINUX_REPO_GPG_PRIVATE_KEY` and, when
   needed, its passphrase as `LINUX_REPO_GPG_PASSPHRASE`.
6. Allow GitHub Actions in the private source repository.

After the first successful release creates the `gh-pages` branch, configure
GitHub Pages in `yousef-muc/portp2p` to deploy from the branch `gh-pages` and
the repository root. The package URLs should then resolve below
`https://yousef-muc.github.io/portp2p/`.

## Local Snapshot

```sh
goreleaser release --snapshot --clean
```

Expected artifacts:

- tarballs for macOS and Linux
- zip archives for Windows
- checksums
- `.deb`
- `.rpm`
- generated Homebrew formula at `dist/homebrew/portp2p.rb`

Useful local checks:

```sh
tar -tzf dist/portp2p_VERSION_darwin_arm64.tar.gz
(cd dist && shasum -a 256 -c checksums.txt)
ruby -c dist/homebrew/portp2p.rb
./dist/portp2p_darwin_arm64*/portp2p version
```

When running snapshots outside a Git repository, GoReleaser accepts the build
but uses placeholder GitHub URLs in generated metadata. Tagged releases must run
from the real Git repository so release URLs and commit metadata are populated
correctly.

## Homebrew

Expected user flow:

```sh
brew tap yousef-muc/tap
brew install portp2p
portp2p version
```

Homebrew installs only the `portp2p` binary. It does not start a background
service. Users can run `portp2p server`, `portp2p relay`, `portp2p share`, or
`portp2p connect` explicitly.

GoReleaser currently recommends `homebrew_casks` for prebuilt binaries, but
`portp2p` intentionally follows the same formula-based UX as `nap`: users should
run `brew install portp2p`, not `brew install --cask portp2p`. The GitHub
workflow pins GoReleaser to the locally verified v2 release line so a future
removal of deprecated formula generation does not unexpectedly break tag
releases.

## Linux Packages

Expected user flow:

```sh
curl -fsSL https://yousef-muc.github.io/portp2p/install.sh | sh
```

Debian and Ubuntu users can also configure the signed APT repository manually:

```sh
sudo install -d -m 0755 /usr/share/keyrings
curl -fsSL https://yousef-muc.github.io/portp2p/apt/gpg/portp2p.gpg | sudo tee /usr/share/keyrings/portp2p-archive-keyring.gpg >/dev/null
echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/portp2p-archive-keyring.gpg] https://yousef-muc.github.io/portp2p/apt stable main" | sudo tee /etc/apt/sources.list.d/portp2p.list >/dev/null
sudo apt update
sudo apt install portp2p
```

RPM-based distributions can configure the generated DNF/YUM repository:

```sh
sudo curl -fsSL https://yousef-muc.github.io/portp2p/rpm/portp2p.repo -o /etc/yum.repos.d/portp2p.repo
sudo dnf install portp2p
```

Direct package installation remains available as a fallback:

```sh
sudo apt install ./portp2p_VERSION_linux_amd64.deb
sudo rpm -i ./portp2p_VERSION_linux_amd64.rpm
```

Packages install:

```text
/usr/bin/portp2p
/usr/share/doc/portp2p/README.md
/usr/share/doc/portp2p/docs
```

Package sanity checks:

```sh
portp2p version
portp2p --help
portp2p server --help
```

The release workflow publishes static Linux package repositories to the public
distribution repository's `gh-pages` branch:

```text
https://yousef-muc.github.io/portp2p/apt
https://yousef-muc.github.io/portp2p/rpm
```

APT metadata is signed with `InRelease` and `Release.gpg`. RPM repository
metadata is signed through `repomd.xml.asc`, and RPM packages are signed during
the nFPM package build. The generated `portp2p.repo` enables both
`repo_gpgcheck=1` and `gpgcheck=1`.

## GitHub Release

Before creating a tag:

```sh
git status --short
go mod tidy
git diff --exit-code -- go.mod go.sum
go test ./...
bash -n scripts/release/publish-linux-repos.sh
bash -n scripts/release/sync-public-repo-docs.sh
```

The worktree must be clean, the public repository documentation must already be
committed, and the manual QA checklist plus local GoReleaser snapshot must have
passed. Release tags should point at a commit already present on `main`.

Tag releases are built through GoReleaser:

```sh
git push origin main
git tag v1.0.0
git push origin v1.0.0
```

A normal `git push origin main` does not publish a user-facing version. It only
updates the private source repository. Publishing requires a new `v*` tag.

When the tag workflow succeeds, it publishes the GitHub release, Homebrew
formula, APT repository, DNF/YUM repository, and checksums automatically. No
manual asset copying is required.

The private source repository needs a `HOMEBREW_TAP_GITHUB_TOKEN` repository
secret. The token is used for public release publishing, Homebrew tap updates,
and Linux repository publishing, so it needs write access to:

```text
yousef-muc/portp2p
yousef-muc/homebrew-tap
```

Linux repository signing uses:

```text
LINUX_REPO_GPG_PRIVATE_KEY
LINUX_REPO_GPG_PASSPHRASE  # optional
```

The same signing key is used for APT repository metadata, RPM repository
metadata, and RPM package signatures.

The workflow serializes releases and does not cancel a running publish job when
another tag is pushed. It also validates required secrets before building, then
checks that `go mod tidy` leaves `go.mod` and `go.sum` unchanged.

## Post-Release Verification

After the workflow completes, verify:

```sh
gh release view v1.0.0 --repo yousef-muc/portp2p
curl -fsSL https://yousef-muc.github.io/portp2p/install.sh | head
brew update
brew info yousef-muc/tap/portp2p
```

Also confirm that the public release contains all six platform archives,
`checksums.txt`, both `.deb` packages, and both `.rpm` packages. Install and run
`portp2p version` on at least one macOS host and one Linux host before announcing
the release.

If publishing fails after creating some artifacts, do not move or recreate the
same tag. Fix the release configuration on `main`, use the next patch version,
and verify the public release, Homebrew formula, and package repositories again.
