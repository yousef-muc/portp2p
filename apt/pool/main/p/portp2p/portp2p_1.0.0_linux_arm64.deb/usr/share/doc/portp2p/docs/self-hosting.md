# Self-Hosting

`portp2p` can run its own rendezvous and relay infrastructure. Self-hosting is
the supported path until an official public service is chosen and injected as a
build-time default.

## Roles

`portp2p` has three infrastructure modes:

- `portp2p rendezvous`: HTTP control plane only.
- `portp2p relay`: libp2p Circuit Relay v2 only.
- `portp2p server`: combined rendezvous plus relay in one process.

For most deployments, start with the combined server.

## Combined Server

```sh
portp2p server --plain \
  --listen 0.0.0.0:8080 \
  --p2p-listen /ip4/0.0.0.0/tcp/4001 \
  --identity /var/lib/portp2p/identity.key
```

Open the HTTP port used by `--listen` and the libp2p TCP port used by
`--p2p-listen`.

Clients then use:

```sh
portp2p share 3000 --plain --server http://SERVER_HOST:8080
portp2p connect <code> --plain --server http://SERVER_HOST:8080
```

To use the relay path explicitly, copy one printed `Relay addr` from the server
startup output and pass it to `share`:

```sh
portp2p share 3000 --plain \
  --server http://SERVER_HOST:8080 \
  --relay /ip4/SERVER_IP/tcp/4001/p2p/<relay-peer-id>
```

The connector can force the relay path for verification:

```sh
portp2p connect <code> --plain \
  --server http://SERVER_HOST:8080 \
  --relay-only
```

## Split Rendezvous And Relay

Run rendezvous:

```sh
portp2p rendezvous --plain \
  --listen 0.0.0.0:8080 \
  --identity /var/lib/portp2p/rendezvous.key
```

Run relay:

```sh
portp2p relay --plain \
  --p2p-listen /ip4/0.0.0.0/tcp/4001 \
  --identity /var/lib/portp2p/relay.key
```

Use the relay address printed by the relay process with `share --relay`.

## Recommended Limits

Rendezvous limits:

```sh
portp2p server --plain \
  --listen 0.0.0.0:8080 \
  --p2p-listen /ip4/0.0.0.0/tcp/4001 \
  --rate-limit-requests 120 \
  --rate-limit-window 1m \
  --max-control-bytes 65536 \
  --max-sessions 10000 \
  --max-sessions-per-remote 16 \
  --max-addrs-per-share 32
```

Relay limits:

```sh
portp2p server --plain \
  --listen 0.0.0.0:8080 \
  --p2p-listen /ip4/0.0.0.0/tcp/4001 \
  --relay-limit-duration 2m \
  --relay-limit-bytes 131072 \
  --relay-reservation-ttl 1h \
  --relay-max-reservations 128 \
  --relay-max-circuits 16 \
  --relay-buffer-size 2048 \
  --relay-max-reservations-per-peer 1 \
  --relay-max-reservations-per-ip 8 \
  --relay-max-reservations-per-asn 32
```

Adjust these values for your traffic. Public infrastructure should use explicit
limits, metrics scraping, and alerting.

## Health, Readiness, And Metrics

The rendezvous HTTP service exposes:

```sh
curl http://SERVER_HOST:8080/healthz
curl http://SERVER_HOST:8080/readyz
curl http://SERVER_HOST:8080/metrics
```

Use `/healthz` for basic liveness, `/readyz` to inspect effective limits, and
`/metrics` for Prometheus-compatible operational metrics.

## Identity

Use `--identity` for stable Peer IDs:

```sh
portp2p server --identity /var/lib/portp2p/identity.key
```

The identity file is created with private-file permissions. Back it up if you
want the same relay Peer ID after moving hosts.

## Configuration

Configuration precedence is:

1. CLI flags
2. Environment variables
3. JSON config file from `--config` or `PORTP2P_CONFIG`
4. Build-time defaults

Example:

```json
{
  "server_url": "http://SERVER_HOST:8080",
  "log_level": "info",
  "identity_path": "/var/lib/portp2p/identity.key"
}
```

Environment variables:

```sh
PORTP2P_SERVER=http://SERVER_HOST:8080
PORTP2P_LOG_LEVEL=info
PORTP2P_IDENTITY=/var/lib/portp2p/identity.key
PORTP2P_CONFIG=/etc/portp2p/config.json
```
