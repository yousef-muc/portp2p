# Self-Hosting

`portp2p` can run its own rendezvous and relay infrastructure. Self-hosting is
the supported path until an official public service is chosen and injected as a
build-time default.

## Roles

`portp2p` has three infrastructure modes:

- `portp2p rendezvous`: HTTP control plane only.
- `portp2p relay`: libp2p Circuit Relay v2 only.
- `portp2p server`: combined rendezvous plus relay in one process.

For most deployments, start with the combined server.

The rendezvous HTTP listener defaults to `127.0.0.1:8080` and does not
terminate TLS. Public deployments must place it behind an HTTPS reverse proxy
or explicitly bind it to a protected internal network.

## Combined Server

```sh
portp2p server --plain \
  --listen 0.0.0.0:8080 \
  --p2p-listen /ip4/0.0.0.0/tcp/4001 \
  --advertise-relay /dns4/relay.example.com/tcp/4001/p2p/<relay-peer-id> \
  --identity /var/lib/portp2p/identity.key
```

Open the HTTP port used by `--listen` and the libp2p TCP port used by
`--p2p-listen`.

Clients then use:

```sh
portp2p share 3000 --plain --server http://SERVER_HOST:8080
portp2p connect <code> --plain --server http://SERVER_HOST:8080
```

`share` automatically fetches the current relay addresses from `GET /v1/info`
and reserves the first reachable relay. This lets the operator change relays
without publishing new client builds. `--advertise-relay` is optional for local
use, but public deployments should set it to a stable, externally reachable
DNS or IP multiaddr.

To override discovery explicitly, pass a relay to `share`:

```sh
portp2p share 3000 --plain \
  --server http://SERVER_HOST:8080 \
  --relay /ip4/SERVER_IP/tcp/4001/p2p/<relay-peer-id>
```

The connector can force the relay path for verification:

```sh
portp2p connect <code> --plain \
  --server http://SERVER_HOST:8080 \
  --relay-only
```

## Split Rendezvous And Relay

Run rendezvous:

```sh
portp2p rendezvous --plain \
  --listen 0.0.0.0:8080 \
  --advertise-relay /dns4/relay.example.com/tcp/4001/p2p/<relay-peer-id> \
  --identity /var/lib/portp2p/rendezvous.key
```

Run relay:

```sh
portp2p relay --plain \
  --p2p-listen /ip4/0.0.0.0/tcp/4001 \
  --identity /var/lib/portp2p/relay.key
```

Configure the relay address on the rendezvous process with
`--advertise-relay`. Clients then discover it automatically; `share --relay`
remains an explicit override.

## Recommended Limits

Rendezvous limits:

```sh
portp2p server --plain \
  --listen 0.0.0.0:8080 \
  --p2p-listen /ip4/0.0.0.0/tcp/4001 \
  --rate-limit-requests 120 \
  --rate-limit-window 1m \
  --max-control-bytes 65536 \
  --max-sessions 10000 \
  --max-sessions-per-remote 16 \
  --max-addrs-per-share 32
```

Relay limits:

```sh
portp2p server --plain \
  --listen 0.0.0.0:8080 \
  --p2p-listen /ip4/0.0.0.0/tcp/4001 \
  --relay-limit-duration 24h \
  --relay-limit-bytes 10737418240 \
  --relay-reservation-ttl 1h \
  --relay-max-reservations 128 \
  --relay-max-circuits 64 \
  --relay-buffer-size 16384 \
  --relay-max-reservations-per-peer 1 \
  --relay-max-reservations-per-ip 8 \
  --relay-max-reservations-per-asn 32
```

Adjust these values for your traffic. Public infrastructure should use explicit
limits, metrics scraping, and alerting.

The production defaults already cap rendezvous at 10,000 active sessions and
16 sessions per source address. Set either value to `0` only when an external
system provides an equivalent limit.

The defaults permit 24-hour connections and 10 GiB per direction so browser
applications, large downloads, and long-lived WebSockets are not cut off by
the much smaller upstream Circuit Relay defaults. Relay reservations remain
one hour but are refreshed automatically by a running `share` process.
The share also refreshes its rendezvous registration without extending the
original share expiry, allowing active shares to recover after a rendezvous
process restart.

For users behind HTTP proxies or restrictive firewalls, expose the relay over
WSS on port 443 in addition to native TCP. See
[Proxy And WebSocket Operation](proxies-and-websockets.md).
When the reverse proxy runs on the same host, pass
`--trusted-proxy 127.0.0.1`; add other proxy IPs or CIDRs only when they are
under your control.

## Health, Readiness, And Metrics

The rendezvous HTTP service exposes:

```sh
curl http://SERVER_HOST:8080/healthz
curl http://SERVER_HOST:8080/readyz
curl http://SERVER_HOST:8080/metrics
curl http://SERVER_HOST:8080/v1/info
```

Use `/healthz` for basic liveness, `/readyz` to inspect effective limits, and
`/metrics` for Prometheus-compatible operational metrics. `/v1/info` returns
the current relay discovery configuration used by `share`.

## Identity

Use `--identity` for stable Peer IDs:

```sh
portp2p server --identity /var/lib/portp2p/identity.key
```

The identity file is created with private-file permissions. Back it up if you
want the same relay Peer ID after moving hosts.

## Configuration

Configuration precedence is:

1. CLI flags
2. Environment variables
3. JSON config file from `--config` or `PORTP2P_CONFIG`
4. Build-time defaults

Example:

```json
{
  "server_url": "http://SERVER_HOST:8080",
  "log_level": "info",
  "identity_path": "/var/lib/portp2p/identity.key",
  "proxy_url": "http://proxy.example.com:3128"
}
```

Environment variables:

```sh
PORTP2P_SERVER=http://SERVER_HOST:8080
PORTP2P_LOG_LEVEL=info
PORTP2P_IDENTITY=/var/lib/portp2p/identity.key
PORTP2P_PROXY=http://proxy.example.com:3128
PORTP2P_CONFIG=/etc/portp2p/config.json
```
