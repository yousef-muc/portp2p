# Security Model

`portp2p` is intentionally narrow: it shares one local TCP port, not a machine.

## What A Share Grants

A share code grants access to exactly one local service:

```text
127.0.0.1:<port>
```

`share` never forwards arbitrary target hosts, subnets, filesystems, shells, or
multiple ports. The share side opens the target only after an authenticated
tunnel stream is accepted.

## Share Codes

Share codes are bearer capabilities. Anyone with a live code can try to connect
until the share expires or the sharer stops it.

Handle share codes like temporary passwords:

- Send them only to intended recipients.
- Do not paste them into public logs or issue trackers.
- Prefer short TTLs for sensitive services.
- Stop `share` with Ctrl+C when access is no longer needed.

The rendezvous server receives and stores only a hash of the share code. It does
not need the cleartext share code to resolve peers.

## Tunnel Authentication

Each tunnel stream starts with a capability frame derived from the share code.
The share side verifies:

- the share code hash,
- the connector Peer ID,
- the sharer Peer ID,
- the capability proof,
- and a nonce that is rejected if replayed.

The share side opens `127.0.0.1:<port>` only after these checks pass.

## Transport Encryption

Data-plane traffic uses libp2p streams. libp2p negotiates encrypted peer-to-peer
connections; relays forward libp2p traffic but are not the application endpoint.

When Circuit Relay is used, the relay is infrastructure for reachability. It is
not given the share code, and it is not the local target service.

## Rendezvous Data

Rendezvous stores temporary metadata:

- code hash,
- peer ID,
- advertised libp2p addresses,
- target port,
- tunnel protocol,
- reachability and capability metadata,
- expiry time.

It does not transport tunneled data. Data moves over libp2p streams between the
connector and sharer, directly or through relay.

## Defaults

Safety defaults:

- `share` targets `127.0.0.1:<port>`.
- `connect` binds to `127.0.0.1`.
- share sessions have TTLs.
- the share side checks that the target port is reachable before registration.
- the connector binds its local listener before dialing the peer.
- concurrent tunnel streams are limited by default.
- unauthenticated tunnel handshakes have separate concurrency and time limits.
- rendezvous supports request size, rate, session, per-remote, and address
  limits.
- relay/server modes expose configurable Circuit Relay resource limits.

## Operational Guidance

For self-hosted public infrastructure:

- run explicit rendezvous limits,
- run explicit relay limits,
- configure `--trusted-proxy` when and only when a controlled reverse proxy
  supplies client addresses,
- keep metrics,
- alert on rate-limit denials, session-limit denials, and unusual active session
  counts,
- protect the host and network like public internet infrastructure,
- rotate or disable infrastructure that is abused.

Do not hardcode a public default rendezvous URL until the public service has
abuse controls, metrics scraping, alerting, and an operating plan.

## Out Of Scope

`portp2p` 1.0 does not provide:

- user accounts,
- persistent service bridges,
- access control lists,
- arbitrary host forwarding,
- subnet forwarding,
- filesystem sharing,
- remote shell access,
- custom NAT traversal research beyond libp2p.

Environment-proven NAT behavior and DCUtR tuning are deferred until after
release/build readiness. The intended 1.0 fallback for difficult networks is
Circuit Relay v2.
