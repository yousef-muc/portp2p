# Proxy And WebSocket Operation

`portp2p` forwards raw TCP streams. HTTP, streaming responses, Server-Sent
Events, HTTP Upgrade, and application WebSockets therefore pass through without
application-specific parsing. This includes ComfyUI's HTTP API and progress
WebSocket.

## Client Proxy Configuration

Go's standard proxy variables work without additional flags:

```sh
export HTTPS_PROXY=http://user:password@proxy.example.com:3128
export HTTP_PROXY=http://user:password@proxy.example.com:3128
export NO_PROXY=127.0.0.1,localhost
portp2p connect <code> --server https://relay.example.com
```

To apply one proxy consistently to rendezvous and WSS relay traffic, use:

```sh
portp2p connect <code> \
  --server https://relay.example.com \
  --proxy http://user:password@proxy.example.com:3128
```

SOCKS5 is also supported with `--proxy socks5://127.0.0.1:1080`. The same value
can be stored as `proxy_url` or `PORTP2P_PROXY`. `status` reports only whether
the proxy is explicit, environment-provided, or absent; it never prints the
URL or credentials.

Native TCP and QUIC cannot traverse a conventional HTTP CONNECT proxy by
themselves. The public relay must therefore publish a WSS address. libp2p tries
the relay addresses registered for the share and uses WSS through the proxy
when native transports are unavailable. When proxy configuration is detected
and a WSS relay address exists, `connect` tries that relay path before direct
TCP/QUIC so restrictive networks do not incur the normal direct-dial timeout.

## Public Relay Over WSS

Run native TCP and an internal plain-WebSocket listener on the same relay peer:

```sh
portp2p server --plain \
  --listen 127.0.0.1:8080 \
  --trusted-proxy 127.0.0.1 \
  --p2p-listen /ip4/0.0.0.0/tcp/4001 \
  --p2p-listen /ip4/127.0.0.1/tcp/4002/ws \
  --advertise-relay /dns4/relay.example.com/tcp/443/tls/ws/p2p/<peer-id> \
  --advertise-relay /dns4/relay.example.com/tcp/4001/p2p/<peer-id> \
  --identity /var/lib/portp2p/identity.key
```

Keep the WSS address first. One successful reservation is announced through
all discovered addresses of that relay peer, allowing each connector to choose
WSS:443 or native TCP independently.

On the first deployment, start the server once with the persistent identity to
obtain its Peer ID, then restart it with the matching `--advertise-relay`
values. Startup fails if an advertised Peer ID does not match the running
server identity.

Terminate TLS and route WebSocket upgrades to port 4002. A minimal Caddy shape
is:

```caddyfile
relay.example.com {
    @libp2p_websocket {
        header Connection *Upgrade*
        header Upgrade websocket
    }
    handle @libp2p_websocket {
        reverse_proxy 127.0.0.1:4002
    }
    handle {
        reverse_proxy 127.0.0.1:8080
    }
}
```

Expose TCP 4001 directly when possible and HTTPS/WSS 443 through the reverse
proxy. Do not expose the internal plain-WebSocket port 4002 publicly.

`--trusted-proxy 127.0.0.1` allows the loopback reverse proxy to supply the
real client address through `X-Forwarded-For`. Only configure addresses or
CIDRs belonging to proxies you control. Without this flag, forwarded headers
are ignored so internet clients cannot spoof their source address.

## Operational Limits

The product relay defaults allow 24-hour connections, 10 GiB per direction,
64 concurrent circuits per peer, and a 16 KiB relay buffer. These values avoid
the upstream Circuit Relay defaults of two minutes and 128 KiB, which are too
small for interactive browser applications and generated media.

Keep finite limits on public infrastructure. Increase them deliberately when
the expected workload needs more, and monitor relay bandwidth and active
circuits. A running share refreshes its relay reservation before expiry.
