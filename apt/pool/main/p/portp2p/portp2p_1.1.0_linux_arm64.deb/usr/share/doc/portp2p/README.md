# portp2p

`portp2p` is a Go CLI for making one local TCP service available as localhost on another computer.

```sh
portp2p share 3000
portp2p connect <uuid>
```

The product goal is intentionally narrow: expose a service, not a machine. A share is one capability for one TCP port on `127.0.0.1:<port>`.

## Documentation

- [Installation](docs/installation.md)
- [Self-hosting](docs/self-hosting.md)
- [Security model](docs/security.md)
- [Release and packaging](docs/release.md)
- [Public repository README](docs/public-repo/README.md)
- [Public repository agent guide](docs/public-repo/AGENTS.md)
- [Manual QA checklist](docs/manual-qa.md)
- [Product 1.0 scope](docs/product-1.0.md)

## Implemented Capabilities

This repository currently contains:

- Cobra CLI with `share`, `connect`, `status`, `server`, `rendezvous`, `relay`, and `version`.
- Basic Bubble Tea output path for interactive share/connect commands.
- UUIDv4 share code generation and code hashing.
- Local libp2p host startup for peer IDs and listen multiaddrs.
- Persistent local libp2p identity via `--identity`, `PORTP2P_IDENTITY`, or `identity_path`.
- HTTP CONNECT and SOCKS5 proxy support via `--proxy`, `PORTP2P_PROXY`, or `proxy_url`.
- Build metadata in `version` output and rendezvous control-plane `User-Agent`.
- GoReleaser release pipeline for public GitHub releases, Homebrew, and Linux packages.
- Manual release QA checklist for direct, relay, config, lifecycle, hardening, and packaging checks.
- Bounded retries for transient rendezvous control-plane failures.
- In-memory rendezvous session store primitives.
- Minimal rendezvous HTTP control plane with in-memory TTL cleanup.
- Local TCP tunnel building blocks.
- First libp2p tunnel stream smoke path over `/portp2p/tunnel/1.0.0`.
- Local TCP forwarding over libp2p tunnel streams.
- Initial UUID capability proof on each tunnel stream before the share side opens `127.0.0.1:<port>`.
- Share target preflight check before rendezvous registration.
- Replay protection for tunnel capability nonces on the share side.
- Configurable concurrent tunnel stream limit per share.
- Consistent plain and JSON command error output for scripting and automation.
- Explicit `CloseShare` lifecycle so shares are removed from rendezvous on shutdown.
- Circuit Relay v2 service startup for `relay` and combined `server` modes.
- Share-side Circuit Relay v2 reservations with relayed `/p2p-circuit/p2p/<peer>` addresses published through rendezvous.
- Connector-side `--relay-only` dialing for explicit Circuit Relay path verification.
- Connector-side direct-first dialing with relay fallback when direct dialing fails.
- Connector-side dial address validation and direct-address prioritization before relay fallback.
- Rendezvous carries the shared target port so `connect <uuid>` can bind the same local port by default.
- Rendezvous carries reachability and transport capability metadata for path selection and future AutoNAT/DCUtR work.
- libp2p hosts start with AutoNATv2 and Hole Punching enabled.
- Relay and combined server hosts provide libp2p AutoNAT service support for future reachability checks.
- Rendezvous exposes `/readyz` and configurable per-IP control-plane rate limits.
- Rendezvous supports configurable active-session and per-share address limits.
- Rendezvous exposes Prometheus-compatible `/metrics` for core control-plane counters.
- Relay and combined server modes expose configurable Circuit Relay resource limits.
- Initial protocol types for the rendezvous control plane.

Environment-proven NAT behavior and DCUtR path tuning are deferred until after release/build readiness.

## Safety Defaults

- `share` targets only `127.0.0.1:<port>`.
- `connect` binds to `127.0.0.1` by default.
- No public default rendezvous URL is hardcoded yet.
- Share codes should not be logged by production code.

## Configuration

`portp2p` resolves configuration in this order:

1. CLI flags such as `--server`, `--log-level`, `--identity`, and `--proxy`
2. Environment variables such as `PORTP2P_SERVER`, `PORTP2P_LOG_LEVEL`, `PORTP2P_IDENTITY`, and `PORTP2P_PROXY`
3. JSON config file from `--config` or `PORTP2P_CONFIG`
4. Build-time defaults

Example config:

```json
{
  "server_url": "http://127.0.0.1:8080",
  "log_level": "info",
  "identity_path": "/Users/you/.config/portp2p/identity.key",
  "proxy_url": "http://proxy.example.com:3128"
}
```

The identity file stores the local libp2p private key with `0600` permissions. Keeping it stable gives `share`, `connect`, `relay`, and `server` a stable Peer ID across restarts. Use `--identity <path>` for portable or isolated runs.

Rendezvous control requests use bounded retries for transient network errors and HTTP `408`, `500`, `502`, `503`, or `504` responses. Tune them with `--control-timeout`, `--control-retries`, and `--control-retry-backoff`.

Standard `HTTP_PROXY`, `HTTPS_PROXY`, and `NO_PROXY` environment variables are honored automatically. An explicit `--proxy` applies the same HTTP CONNECT or SOCKS5 proxy to rendezvous requests and WSS relay traffic. Proxy credentials are never shown by `status`.
When a proxy and WSS relay address are both present, `connect` automatically tries the proxy-compatible relay path before native direct transports.

## Build Metadata

Release builds can inject version metadata without changing source files:

```sh
go build -ldflags "\
  -X github.com/yousef-muc/portp2p/internal/version.Version=1.0.0 \
  -X github.com/yousef-muc/portp2p/internal/version.Commit=$(git rev-parse --short HEAD) \
  -X github.com/yousef-muc/portp2p/internal/version.Date=$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
  ./cmd/portp2p
```

`portp2p version` prints the injected version, commit, build date, Go runtime, OS/arch, default server URL, and rendezvous control-plane user agent. The default server URL remains empty until an official public service is ready; if needed later, inject it with `-X github.com/yousef-muc/portp2p/internal/version.DefaultServerURL=<url>`.

See [docs/release.md](docs/release.md) for the full release flow. The private source repository publishes user-facing builds to the public `yousef-muc/portp2p` distribution repository.

Before tagging a release, run the manual checks in [docs/manual-qa.md](docs/manual-qa.md).

## Local Usage

```sh
go run ./cmd/portp2p --help
go run ./cmd/portp2p share 3000 --plain
go run ./cmd/portp2p status --plain
go run ./cmd/portp2p rendezvous --listen 127.0.0.1:8080
```

With a local rendezvous server running:

```sh
go run ./cmd/portp2p share 3000 --plain --server http://127.0.0.1:8080
go run ./cmd/portp2p connect <uuid> --plain --server http://127.0.0.1:8080
```

By default, `connect` listens on the shared port returned by rendezvous. Use `--port <local-port>` to override it:

```sh
go run ./cmd/portp2p connect <uuid> --plain --server http://127.0.0.1:8080 --port 9000
```

`share --server` starts a local libp2p host, registers its Peer ID and listen addresses, installs a `/portp2p/tunnel/1.0.0` stream handler, and keeps running until Ctrl+C. `connect --server` resolves the share, dials it over libp2p, and forwards local TCP connections over libp2p tunnel streams.

The tunnel transports raw TCP bidirectionally, so HTTP upgrades and application WebSockets such as ComfyUI progress updates pass through unchanged. Relay reservations are refreshed while a share is running, and clean TCP half-closes are preserved for large request/response transfers.

Each tunnel stream starts with an `open_tunnel` capability frame derived from the UUID share code. The share side verifies that proof, validates the nonce/proof encoding, rejects replayed nonces, and enforces `--max-tunnel-streams` before dialing its local target.

When `share` stops or its TTL elapses, it asks rendezvous to close the registered session. `GET /healthz` also cleans expired sessions before reporting `active_sessions`.

For a local-only dial smoke check:

```sh
go run ./cmd/portp2p rendezvous --listen 127.0.0.1:8080 --plain
python3 -m http.server 3000 --bind 127.0.0.1
go run ./cmd/portp2p share 3000 --plain --server http://127.0.0.1:8080 --p2p-listen /ip4/127.0.0.1/tcp/0
go run ./cmd/portp2p connect <uuid> --plain --server http://127.0.0.1:8080 --port 9000 --p2p-listen /ip4/127.0.0.1/tcp/0
curl -I http://127.0.0.1:9000/
```

Use `share --register-only` only for inspecting rendezvous registration without keeping the libp2p host alive. By default, `share --server` checks that `127.0.0.1:<port>` is reachable before registration; use `--skip-target-check` only for deliberate advanced flows.

Running shares periodically restore their rendezvous registration after a
server restart without extending the original `--expires` deadline. Pending
tunnel authentication is separately bounded by `--max-pending-handshakes` and
`--handshake-timeout`.

Relay service smoke check:

```sh
go run ./cmd/portp2p relay --plain --p2p-listen /ip4/127.0.0.1/tcp/0
```

Combined rendezvous plus relay:

```sh
go run ./cmd/portp2p server --plain --listen 127.0.0.1:8080 --p2p-listen /ip4/127.0.0.1/tcp/0
```

These commands start a libp2p Circuit Relay v2 service and print `/p2p-circuit` relay addresses. The combined `server` also publishes its relay addresses through `GET /v1/info`; `share` queries that endpoint automatically whenever no explicit `--relay` is supplied.

For a public deployment, publish a stable externally reachable address instead of an internal interface address:

```sh
portp2p server --plain \
  --listen 0.0.0.0:8080 \
  --p2p-listen /ip4/0.0.0.0/tcp/4001 \
  --advertise-relay /dns4/relay.example.com/tcp/4001/p2p/<relay-peer-id>
```

The discovery response adds `/p2p-circuit` when needed. Changing `--advertise-relay` updates clients without requiring a new client build. An explicit `share --relay` remains available and takes precedence over discovery. For restrictive networks and HTTP proxies, deploy an additional WSS relay address on port 443 as described in [docs/proxies-and-websockets.md](docs/proxies-and-websockets.md).

The HTTP control listener is plain HTTP and defaults to `127.0.0.1:8080`.
Terminate HTTPS at a reverse proxy for public deployments. When that proxy is
local, add `--trusted-proxy 127.0.0.1` so per-client rate and session limits use
the proxy-supplied address without trusting arbitrary forwarded headers.

Relay resource limits can be tuned for self-hosted deployments:

```sh
go run ./cmd/portp2p relay --plain \
  --p2p-listen /ip4/127.0.0.1/tcp/0 \
  --relay-limit-duration 24h \
  --relay-limit-bytes 10737418240 \
  --relay-reservation-ttl 1h \
  --relay-max-reservations 128 \
  --relay-max-circuits 64 \
  --relay-buffer-size 16384 \
  --relay-max-reservations-per-peer 1 \
  --relay-max-reservations-per-ip 8 \
  --relay-max-reservations-per-asn 32
```

`server` accepts the same `--relay-*` flags. Set `--relay-limit-duration` or `--relay-limit-bytes` to a negative value to disable per-connection duration/data limits. Plain and JSON startup output include the effective relay resource settings.

Rendezvous hardening flags:

```sh
go run ./cmd/portp2p rendezvous --listen 127.0.0.1:8080 \
  --rate-limit-requests 120 \
  --rate-limit-window 1m \
  --max-control-bytes 65536 \
  --max-sessions 0 \
  --max-sessions-per-remote 0 \
  --max-addrs-per-share 32
```

Use `GET /readyz` to inspect readiness and effective control-plane limits. Use `GET /metrics` to scrape Prometheus-compatible operational metrics such as active sessions, register/resolve/close request counts, limit denials, and expired cleanup counts.

Share-side relay reservation:

```sh
go run ./cmd/portp2p relay --plain --p2p-listen /ip4/127.0.0.1/tcp/0
go run ./cmd/portp2p rendezvous --listen 127.0.0.1:8080 --plain
go run ./cmd/portp2p share 3000 --plain \
  --server http://127.0.0.1:8080 \
  --p2p-listen /ip4/127.0.0.1/tcp/0 \
  --relay /ip4/127.0.0.1/tcp/<relay-port>/p2p/<relay-peer-id>
```

The share output should include an additional relayed address like:

```text
/ip4/127.0.0.1/tcp/<relay-port>/p2p/<relay-peer-id>/p2p-circuit/p2p/<share-peer-id>
```

Connect resolves and can dial shares that include those relay addresses. To force the relay path for verification:

```sh
go run ./cmd/portp2p connect <uuid> --plain \
  --server http://127.0.0.1:8080 \
  --port 9000 \
  --relay-only
```

Expected output includes:

```text
Connection: RELAY
Dial path: RELAY
Remote libp2p addr: .../p2p-circuit
```

Without `--relay-only`, `connect` validates and prioritizes direct addresses first, then falls back to relayed addresses if direct dialing fails. Use `--direct-only` to inspect direct dialing without relay fallback. Add `--verbose` to show skipped invalid addresses in plain output; JSON output includes `skipped_addrs` when any resolved addresses were ignored.

`share`, `connect`, `relay`, and `server` output also show reachability metadata. Local hosts enable AutoNATv2 and Hole Punching by default, but reachability can remain `UNKNOWN` until the network has enough information. Relay and combined server modes also enable libp2p AutoNAT service support. For local smoke tests, use `--force-reachability public` or `--force-reachability private` to verify the metadata path; invalid values fail fast.

For scripting:

```sh
go run ./cmd/portp2p share 3000 --json
```

Commands that fail with `--json` emit a JSON error event with `type`, `code`, `message`, and `command`. Plain output prints concise errors to stderr.

## Rendezvous API

The current local rendezvous server exposes:

- `GET /healthz`
- `GET /readyz`
- `GET /metrics`
- `GET /v1/info`
- `POST /v1/shares`
- `POST /v1/shares/close`
- `POST /v1/resolve`

The rendezvous server stores only share metadata keyed by `code_hash`; it does not see cleartext share codes and does not transport tunneled data.
