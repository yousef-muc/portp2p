# Public Service

`portp2p` is designed so an official public rendezvous/relay service can be added later.

Until the official URL is chosen:

- No false public default server URL should be hardcoded.
- Self-hosting remains the supported path with `--server`.
- The default server value may be injected at build time later with `-X github.com/yousef-muc/portp2p/internal/version.DefaultServerURL=<url>`.
- Config and environment overrides should take precedence over build defaults.
- The service publishes its current relay addresses through `GET /v1/info`, so
  relay hosts can change without rebuilding clients.

Planned precedence:

1. CLI flag: `--server`
2. Environment: `PORTP2P_SERVER`
3. JSON config file from `--config` or `PORTP2P_CONFIG`
4. Build-time default

The future public service should use the same binary as self-hosted deployments. Configure its public relay multiaddr with `server --advertise-relay`; `share` uses discovery automatically unless the user supplies `--relay`. The service must include rate limits, relay limits, abuse controls, operational metrics, and metrics scraping/alerting before it becomes the default.
