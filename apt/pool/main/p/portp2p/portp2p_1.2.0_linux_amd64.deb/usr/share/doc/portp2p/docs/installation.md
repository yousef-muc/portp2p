# Installation

`portp2p` ships as one binary named `portp2p`.

No background service is started by default. After installation, choose the role
you want on each machine:

- `portp2p share <port>` on the machine that owns the local service.
- `portp2p connect <code>` on the machine that should access it.
- `portp2p server` or `portp2p rendezvous`/`portp2p relay` for self-hosted
  infrastructure.

## macOS Homebrew

After the first public release:

```sh
brew tap yousef-muc/tap
brew install portp2p
portp2p version
```

## Linux Installer

After the first public release:

```sh
curl -fsSL https://yousef-muc.github.io/portp2p/install.sh | sh
portp2p version
```

The installer configures the signed APT or RPM repository when the host uses
`apt-get`, `dnf`, or `yum`.

## Debian And Ubuntu

Manual APT setup:

```sh
sudo install -d -m 0755 /usr/share/keyrings
curl -fsSL https://yousef-muc.github.io/portp2p/apt/gpg/portp2p.gpg | sudo tee /usr/share/keyrings/portp2p-archive-keyring.gpg >/dev/null
echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/portp2p-archive-keyring.gpg] https://yousef-muc.github.io/portp2p/apt stable main" | sudo tee /etc/apt/sources.list.d/portp2p.list >/dev/null
sudo apt update
sudo apt install portp2p
```

## Fedora, RHEL, CentOS, And Compatible

Manual DNF/YUM setup:

```sh
sudo curl -fsSL https://yousef-muc.github.io/portp2p/rpm/portp2p.repo -o /etc/yum.repos.d/portp2p.repo
sudo dnf install portp2p
```

Use `yum install portp2p` on systems that use `yum` instead of `dnf`.

## GitHub Release Assets

The public distribution repository is:

```text
https://github.com/yousef-muc/portp2p
```

Each release publishes:

- macOS tarballs for amd64 and arm64.
- Linux tarballs for amd64 and arm64.
- Windows zip archives for amd64 and arm64.
- Linux `.deb` packages for amd64 and arm64.
- Linux `.rpm` packages for amd64 and arm64.
- `checksums.txt`.

Verify downloaded assets with:

```sh
shasum -a 256 -c checksums.txt
```

Run:

```sh
portp2p version
portp2p --help
```

## Build From Source

For local development:

```sh
go run ./cmd/portp2p version
go build ./cmd/portp2p
```

Release builds should inject version metadata. See [release.md](release.md).
