# Discovery And Controlled Access

Discovery is an optional layer on top of the normal private share flow. A plain
`portp2p share` remains private, is never searchable, and can be resolved only
by someone who receives its temporary share code directly.

Publishing has two independent choices:

| Visibility | Access | Result |
| --- | --- | --- |
| Public | Direct | Searchable; every user may connect immediately |
| Public | Approval | Searchable; the owner must approve each requester |
| Private | Direct | Invitation-only; invitation holders may connect immediately |
| Private | Approval | Invitation-only; the owner must also approve each requester |

There are no accounts, roles, payments, marketplace rankings, or persistent
database. Listings, requests, and grants are temporary and held in memory.

## Public Direct Listing

The default publication mode is a temporary public listing with direct access:

```sh
portp2p share 3000 --plain \
  --publish \
  --name "Demo service" \
  --description "Temporary public HTTP demo" \
  --category demo \
  --tag http \
  --tag free
```

`--name` is required. Description, category, and up to eight tags are optional.
Discovery cannot be combined with `--register-only`, because a listing must
represent a live process that can authenticate and serve tunnel streams.

The output contains two different capabilities:

- `Private code` is the original private share code and is never published.
- `Public connect code` is intentionally included in public search results.

Search and connect:

```sh
portp2p discover --plain
portp2p discover comfyui --category ai --tag gpu --plain
portp2p discover --service-id svc_... --plain
portp2p connect <public-connect-code> --plain
```

Anyone who finds a public direct listing can connect while it is online. Keep
application-level authentication enabled for sensitive services.

## Stable Signed Services

Add a stable service key when the service should be recognizable across
separate shares:

```sh
portp2p share 8188 --plain \
  --publish \
  --service-key comfyui-home \
  --name "ComfyUI" \
  --category ai \
  --tag gpu
```

The service key is a public label scoped to the publisher identity. Reusing it
with the same identity file produces the same stable Service ID. Only one live
listing may use that Service ID at a time.

The client signs the listing with its persistent Ed25519 libp2p identity.
Searching clients verify the proof before displaying it. A signed publisher
therefore proves continuity of one cryptographic key, not a legal name,
reputation, safety review, or real-world identity.

A discovery operator may separately allowlist selected Publisher IDs. Those
listings show an operator verification marker. It is an assertion by the
currently configured server, not a global portp2p endorsement.

Useful identity commands:

```sh
portp2p status --plain
portp2p identity init
portp2p identity backup /secure/location/portp2p-identity.key
portp2p identity restore /secure/location/portp2p-identity.key
```

The backup is an unencrypted private key and must be stored securely. Replacing
the identity changes the Publisher ID and every derived stable Service ID.

## Approval Access

Approval access requires a stable service key and never publishes a connect
code:

```sh
portp2p share 8188 --plain \
  --publish \
  --name "ComfyUI by request" \
  --service-key comfyui-home \
  --access approval
```

The requester finds the stable Service ID with `portp2p discover`, then sends a
signed request:

```sh
portp2p access request <service-id> --message "Yousef from the demo" --plain
```

The command prints a request ID and a private request token. Keep both until the
request is decided. The running sharer prints each new request and accepts:

```text
approve <request-id>
deny <request-id>
```

The requester checks the result:

```sh
portp2p access status <request-id> --token <request-token> --plain
```

An approved result contains a short-lived connect code. That code is bound to
the requester's libp2p identity, so copying it to another installation does not
transfer the grant.

## Private Discovery

A private listing never appears in public search or result counts. It requires
a stable service key and creates a separate random invitation:

```sh
portp2p share 8188 --plain \
  --publish \
  --name "Private ComfyUI" \
  --service-key comfyui-home \
  --visibility private \
  --access direct
```

Give the printed invitation code only to intended recipients. It is not the
normal private share code and cannot manage the listing. A recipient opens it:

```sh
portp2p access open <invitation-code> --plain
```

For direct access, the result contains a connect code. For owner approval, use
`--access approval` when publishing, then request access with the invitation:

```sh
portp2p access request <invitation-code> --message "Please let me in" --plain
```

Knowing only the stable Service ID does not reveal that a private listing
exists. The rendezvous server stores the invitation hash, not its cleartext.

## Web UI

The embedded Web UI exposes the same four combinations. The Share form selects
Visibility and Access independently. Public approval listings show a Request
access action in search. Private invitations are opened in the dedicated
Private invitation section. Owners approve or deny pending requests from the
active share session.

Requester tokens are kept in browser session storage, not sent in URLs. Closing
that browser session discards the local copy, so keep the page open until a
pending request is decided.

## Lifecycle And Recovery

Listings never outlive their share. They are removed when the sharer stops, the
share expires, or the owner unpublishes it. Requests and grants are removed with
their listing.

If rendezvous restarts, a running sharer restores its registration and listing
during the normal refresh cycle without changing the original expiry deadline.
Temporary access requests and grants are deliberately not persistent and must
be created again after a server restart.

## Privacy And Server Data

The normal private code, discovery connect code, private invitation, listing
management token, request token, and approved grant are separate capabilities.
Publishing never exposes the normal private share code.

The server stores code and token hashes where lookup or authorization permits.
Public metadata is visible in public search. Private metadata is returned only
after presentation of its invitation. Approval listings expose no connect code
until the owner approves a signed requester.

Current clients authorize publication with the underlying share's independent
management token. Public deployments behind a reverse proxy must configure
`--trusted-proxy` only for controlled proxy addresses because source addresses
remain part of rate limiting and legacy protection.

## Operator Limits

Rendezvous and combined server modes provide independent limits:

```sh
portp2p server \
  --max-discovery-listings 1000 \
  --max-discovery-listings-per-remote 4 \
  --max-access-requests 5000 \
  --max-access-requests-per-listing 32 \
  --max-access-requests-per-remote 16 \
  --access-request-ttl 15m \
  --access-grant-ttl 10m \
  --discovery-verified-publisher 12D3KooW...
```

Discovery and access also share the control-plane request-size and rate limits.
Set a count limit to `0` only when an external system supplies equivalent abuse
controls. Request and grant expiry remains mandatory. All state is in memory,
so no account system, role system, or database is required.

## Version Scope

Discovery v1 provides free, temporary public listings. Discovery v2 adds stable
service identities and signed publisher continuity. Access v3 adds private
listings, signed access requests, owner decisions, and requester-bound temporary
grants. Payments, marketplace ranking, reputation, and real-world identity
attestation remain outside the product.
