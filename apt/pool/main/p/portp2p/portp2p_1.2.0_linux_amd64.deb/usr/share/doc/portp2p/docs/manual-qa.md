# Manual QA Checklist

Run this checklist before a release tag. It intentionally describes manual
checks instead of automated test files.

Use fresh terminals for long-running commands. Stop long-running `portp2p`
processes with Ctrl+C after each scenario.

## Baseline

From the private source repository:

```sh
go test ./...
rg --files -g '*_test.go'
go run ./cmd/portp2p version --plain
go run ./cmd/portp2p version --json
go run ./cmd/portp2p status --plain
go run ./cmd/portp2p status --json
```

Expected:

- `go test ./...` compiles all packages and reports `[no test files]`.
- `rg --files -g '*_test.go'` prints nothing.
- `version` includes version, commit, date, Go version, OS/arch, default server
  URL, and user agent.
- `status` includes server, log level, identity path, and control retry settings.

## Local Direct Tunnel

Terminal A:

```sh
go run ./cmd/portp2p rendezvous --plain --listen 127.0.0.1:18080
```

Terminal B:

```sh
python3 -m http.server 3000 --bind 127.0.0.1
```

Terminal C:

```sh
go run ./cmd/portp2p share 3000 --plain \
  --server http://127.0.0.1:18080 \
  --p2p-listen /ip4/127.0.0.1/tcp/0
```

Copy the printed code.

Terminal D:

```sh
go run ./cmd/portp2p connect <code> --plain \
  --server http://127.0.0.1:18080 \
  --port 9000 \
  --p2p-listen /ip4/127.0.0.1/tcp/0
```

Terminal E:

```sh
curl -I http://127.0.0.1:9000/
```

Expected:

- `share` prints a code, Peer ID, direct loopback addresses, and
  `Waiting for libp2p connections`.
- `connect` prints `Connection: DIRECT` and `Forwarding: 127.0.0.1:9000 ->`.
- `curl` returns HTTP `200`.

## Local Web UI

Start a local combined server and a target service as in the direct-tunnel
scenario. Use a separate identity for the Web UI process:

```sh
go run ./cmd/portp2p web --plain \
  --listen 127.0.0.1:4173 \
  --server http://127.0.0.1:18080 \
  --identity /tmp/portp2p-web-ui.key
```

Open `http://127.0.0.1:4173` and manually verify:

1. Create a private share and confirm its code appears under Sessions.
2. Search discovery and confirm the private share is absent.
3. Publish that share, find its separate public code, then unpublish it.
4. Start a second CLI share with a different identity and connect its code from
   the Web UI. Fetch the resulting localhost URL successfully.
5. Stop the connection and share from Sessions, then change the rendezvous URL
   in the Server dialog.
6. Close only the browser tab and confirm any active session continues. Stop
   the Web UI process with Ctrl+C and confirm all of its sessions close.
7. Switch to light mode with the top-bar icon, reload the page, and confirm the
   light preference remains. Switch back to dark mode, reload again, and
   confirm dark mode remains. A fresh browser profile must start in dark mode.

Check the local HTTP boundary:

```sh
curl -i -X PUT http://127.0.0.1:4173/api/config \
  -H 'Content-Type: application/json' \
  -d '{"server_url":"http://127.0.0.1:18080"}'
curl -i http://127.0.0.1:4173/api/state -H 'Host: example.com'
go run ./cmd/portp2p web --listen 0.0.0.0:4199
```

Expected:

- the tokenless mutation and non-loopback Host return HTTP `403`;
- the non-loopback listen address is rejected before startup;
- browser developer tools show no console errors during the workflow;
- security response headers include CSP, frame denial, no-referrer,
  same-origin resource isolation, and a restrictive Permissions Policy.

## Public Discovery

Use separate temporary identities because the combined server and share run on
the same machine.

Terminal A:

```sh
go run ./cmd/portp2p server --plain \
  --listen 127.0.0.1:18085 \
  --p2p-listen /ip4/127.0.0.1/tcp/0 \
  --identity /tmp/portp2p-discovery-server.key
```

Terminal B:

```sh
python3 -m http.server 3000 --bind 127.0.0.1
```

Terminal C:

```sh
go run ./cmd/portp2p share 3000 --plain \
  --server http://127.0.0.1:18085 \
  --identity /tmp/portp2p-discovery-share.key \
  --p2p-listen /ip4/127.0.0.1/tcp/0 \
  --expires 3m \
  --publish --name "Discovery QA" \
  --description "Temporary public QA service" \
  --category qa --tag http
```

Terminal D:

```sh
go run ./cmd/portp2p discover QA --plain \
  --server http://127.0.0.1:18085 \
  --category qa --tag http
```

Copy the printed public connect code, not the private code:

```sh
go run ./cmd/portp2p connect <public-connect-code> --plain \
  --server http://127.0.0.1:18085 \
  --identity /tmp/portp2p-discovery-connect.key \
  --port 9005 \
  --p2p-listen /ip4/127.0.0.1/tcp/0
curl -I http://127.0.0.1:9005/
```

Expected:

- Share output labels separate private and public codes.
- Search returns the metadata and public code, never the private code or its hash.
- Category and tag filters return the listing; a nonmatching filter does not.
- The public code opens a working tunnel and `curl` returns HTTP `200`.
- A normal share without `--publish` never appears in search.
- After stopping the published share, search returns no matching listing.

Restart Terminal A while the published share remains running. Wait up to 35
seconds and search again. The listing must return with the same public connect
code and original expiry time.

## Discovery Access Matrix

Keep the server and local HTTP target from the previous section running. Stop
the previous share before starting each case. Use the separate sharer and
connector identity files shown above.

### Public Approval

Start the share:

```sh
go run ./cmd/portp2p share 3000 --plain \
  --server http://127.0.0.1:18085 \
  --identity /tmp/portp2p-discovery-share.key \
  --p2p-listen /ip4/127.0.0.1/tcp/0 \
  --expires 3m --publish --name "Approval QA" \
  --service-key approval-qa --access approval
```

Find the stable Service ID, then request access from Terminal D:

```sh
go run ./cmd/portp2p discover "Approval QA" --plain \
  --server http://127.0.0.1:18085

go run ./cmd/portp2p access request <service-id> --plain \
  --server http://127.0.0.1:18085 \
  --identity /tmp/portp2p-discovery-connect.key \
  --message "Manual QA"
```

Confirm search contains no connect code. In the sharer's terminal, enter
`approve <request-id>`. Retrieve the result using the printed request token:

```sh
go run ./cmd/portp2p access status <request-id> --token <request-token> --plain \
  --server http://127.0.0.1:18085
```

Connect the approved code with the same connector identity and confirm HTTP
`200`. Then try the same code with a new identity file and confirm the tunnel
authentication is rejected.

Repeat once with `deny <request-id>` and confirm no connect code is returned.

### Private Direct

Start a share with `--visibility private --access direct` and a new stable
service key. Confirm `portp2p discover` does not show the listing and its public
result count does not increase. Open the printed invitation:

```sh
go run ./cmd/portp2p access open <invitation-code> --plain \
  --server http://127.0.0.1:18085
```

Connect the returned code and confirm HTTP `200`. Confirm that the normal
private share code and private discovery invitation are different values.

### Private Approval

Start a share with `--visibility private --access approval`. Confirm it remains
absent from public search. Request through its invitation:

```sh
go run ./cmd/portp2p access request <invitation-code> --plain \
  --server http://127.0.0.1:18085 \
  --identity /tmp/portp2p-discovery-connect.key \
  --message "Private manual QA"
```

Approve it at the sharer, retrieve the status with the request token, and
confirm the returned code works only with the requesting identity.

### Web UI

Repeat the four visibility/access combinations in `portp2p web`. Confirm:

- public approval results show Request access instead of a connect code;
- private invitations open only in the dedicated invitation form;
- pending owner requests appear in the active share session;
- Approve and Deny update requester status;
- an approved code can be moved directly into the Connect form;
- refreshing the tab retains pending requests for that browser session;
- normal private shares never appear in discovery.

## Relay-Only Tunnel

### Automatic server discovery

Terminal A:

```sh
go run ./cmd/portp2p server --plain \
  --listen 127.0.0.1:18081 \
  --p2p-listen /ip4/127.0.0.1/tcp/0 \
  --identity /tmp/portp2p-auto-relay-server.key
```

Confirm discovery in another terminal:

```sh
curl http://127.0.0.1:18081/v1/info
```

With a target running on port 3000, start the share without `--relay`:

```sh
go run ./cmd/portp2p share 3000 --plain \
  --server http://127.0.0.1:18081 \
  --p2p-listen /ip4/127.0.0.1/tcp/0 \
  --identity /tmp/portp2p-auto-relay-share.key
```

Expected:

- `/v1/info` returns `type: server_info`, `relay-discovery-v1`, and at least
  one `/p2p-circuit` relay address.
- `share` prints `Relay source: server discovery`, a relay reservation, and a
  relayed address without receiving an explicit `--relay`.

### Explicit override

Terminal A:

```sh
go run ./cmd/portp2p relay --plain --p2p-listen /ip4/127.0.0.1/tcp/0
```

Copy one printed `Relay addr`.

Terminal B:

```sh
go run ./cmd/portp2p rendezvous --plain --listen 127.0.0.1:18081
```

Terminal C:

```sh
python3 -m http.server 3000 --bind 127.0.0.1
```

Terminal D:

```sh
go run ./cmd/portp2p share 3000 --plain \
  --server http://127.0.0.1:18081 \
  --p2p-listen /ip4/127.0.0.1/tcp/0 \
  --relay <relay-addr>
```

Copy the printed code.

Terminal E:

```sh
go run ./cmd/portp2p connect <code> --plain \
  --server http://127.0.0.1:18081 \
  --port 9001 \
  --p2p-listen /ip4/127.0.0.1/tcp/0 \
  --relay-only
```

Terminal F:

```sh
curl -I http://127.0.0.1:9001/
```

Expected:

- `share` prints a relay reservation and a `/p2p-circuit` address.
- `connect` prints `Connection: RELAY`, `Dial path: RELAY`, and a remote
  `/p2p-circuit` address.
- `curl` returns HTTP `200`.

## Direct-First With Relay Fallback

Repeat the relay-only setup, but run `connect` without `--relay-only`:

```sh
go run ./cmd/portp2p connect <code> --plain \
  --server http://127.0.0.1:18081 \
  --port 9002 \
  --p2p-listen /ip4/127.0.0.1/tcp/0
```

Expected:

- On local loopback, direct dialing may succeed first.
- If direct dialing fails in a real network, relay fallback should still connect.
- The output always shows the chosen `Connection` and `Dial path`.

## ComfyUI, WebSockets, And Large Transfers

Run the combined server, then share a running ComfyUI instance:

```sh
portp2p share 8188 --plain --server http://127.0.0.1:18081
portp2p connect <code> --plain \
  --server http://127.0.0.1:18081 \
  --port 8188 \
  --relay-only
```

Open `http://127.0.0.1:8188`, queue a workflow, and leave the page open while
it runs. Verify that queue state, progress updates, previews, and completed
images continue working. In browser developer tools, the ComfyUI WebSocket
must remain connected without repeated reconnects.

For a reproducible large-transfer check, serve a temporary 256 MiB payload on
the share side and download it through the connector listener:

```sh
mkdir -p /tmp/portp2p-large-qa
dd if=/dev/urandom of=/tmp/portp2p-large-qa/portp2p-large.bin bs=1048576 count=256
cd /tmp/portp2p-large-qa && python3 -m http.server 3000 --bind 127.0.0.1
curl --fail --output /tmp/portp2p-large.received http://127.0.0.1:9001/portp2p-large.bin
shasum -a 256 /tmp/portp2p-large-qa/portp2p-large.bin /tmp/portp2p-large.received
```

Expected:

- The ComfyUI WebSocket remains usable for the full workflow.
- The 256 MiB transfer completes over the relay, well beyond 128 KiB.
- Both SHA-256 values match.

## Relay Reservation Refresh

Start a server with a deliberately short reservation TTL:

```sh
go run ./cmd/portp2p server --plain \
  --listen 127.0.0.1:18084 \
  --p2p-listen /ip4/127.0.0.1/tcp/0 \
  --relay-reservation-ttl 1m
```

Start a share for three minutes with `--verbose`. Wait at least 90 seconds,
then connect with `--relay-only` and perform an HTTP request.

Expected:

- The relay-only connection still succeeds after the original reservation TTL.
- No refresh error is printed. A transient failure is retried every 15 seconds.

Restart the relay process with the same identity and listen address while the
share remains running. Wait up to 30 seconds, then connect again with
`--relay-only`.

Expected:

- the share detects the dropped relay connection and reserves again;
- the relay-only connection succeeds without restarting the share;
- repeated healthy checks do not create repeated reservation requests.

## Proxy And WSS Relay

Against a public deployment configured as described in
`docs/proxies-and-websockets.md`, force an actual HTTP CONNECT proxy:

```sh
portp2p connect <code> --plain --relay-only \
  --server https://relay.example.com \
  --proxy http://user:password@proxy.example.com:3128
```

Expected:

- Rendezvous resolution and the relay connection both succeed through the proxy.
- `Remote libp2p addr` contains `/tls/ws` and `/p2p-circuit`.
- `Dial path` is `RELAY` without waiting for a failed direct attempt first.
- `portp2p status --plain --proxy <proxy-url>` prints `Proxy: explicit` without
  printing the URL, username, or password.

## JSON Output And Errors

```sh
go run ./cmd/portp2p version --json
go run ./cmd/portp2p status --json
go run ./cmd/portp2p discover --json --server http://127.0.0.1:18085
go run ./cmd/portp2p connect not-a-uuid --json
go run ./cmd/portp2p connect not-a-uuid --plain
```

Expected:

- JSON success output is valid JSON.
- JSON error output contains `type: error`, `code`, `message`, and `command`.
- Plain error output starts with `Error:`.
- `go run` may append `exit status 1`; a built binary should not.

## Config And Identity

Create a temporary config:

```sh
mkdir -p /tmp/portp2p-qa
cat > /tmp/portp2p-qa/config.json <<'EOF'
{
  "server_url": "http://127.0.0.1:18100",
  "log_level": "debug",
  "identity_path": "/tmp/portp2p-qa/identity.key",
  "proxy_url": "http://127.0.0.1:3128"
}
EOF
```

Run:

```sh
go run ./cmd/portp2p --config /tmp/portp2p-qa/config.json status --plain
PORTP2P_SERVER=http://127.0.0.1:18101 go run ./cmd/portp2p --config /tmp/portp2p-qa/config.json status --json
go run ./cmd/portp2p --identity /tmp/portp2p-qa/identity.key relay --plain --p2p-listen /ip4/127.0.0.1/tcp/0
```

Stop and run the same relay command again.

Expected:

- `status` uses config values.
- `PORTP2P_SERVER` overrides the config server.
- `PORTP2P_PROXY` overrides the config proxy without exposing its URL in status output.
- The identity file is created with private-file permissions.
- Re-running with the same identity path keeps the same Peer ID.

## Lifecycle And Limits

Preflight failure:

```sh
go run ./cmd/portp2p rendezvous --plain --listen 127.0.0.1:18082
go run ./cmd/portp2p share 39999 --plain --server http://127.0.0.1:18082
curl http://127.0.0.1:18082/healthz
```

Expected:

- `share` fails before registration because no target listens on port `39999`.
- `/healthz` reports `active_sessions: 0`.

Local port conflict:

```sh
python3 -m http.server 9003 --bind 127.0.0.1
go run ./cmd/portp2p connect <valid-code> --plain \
  --server http://127.0.0.1:18080 \
  --port 9003
```

Expected:

- `connect` fails before opening the libp2p tunnel because the local port is in
  use.

Active connection shutdown:

1. Open a long-lived browser, WebSocket, or `nc` connection through a running
   connector.
2. Stop that connector from the CLI or Web UI while the connection is active.
3. Immediately start another listener on the same local port.

Expected:

- the active local connection closes promptly;
- the connector process or Web UI stop action completes;
- the local port can be reused immediately;
- no session remains in the Web UI session list.

Stream limit:

```sh
go run ./cmd/portp2p share 3000 --plain \
  --server http://127.0.0.1:18080 \
  --p2p-listen /ip4/127.0.0.1/tcp/0 \
  --max-tunnel-streams 1
```

Expected:

- Output shows `Max tunnel streams: 1`.
- One normal forwarded `curl` request succeeds.

## Rendezvous Hardening

```sh
go run ./cmd/portp2p rendezvous --plain \
  --listen 127.0.0.1:18083 \
  --rate-limit-requests 3 \
  --rate-limit-window 1m \
  --max-control-bytes 1024 \
  --max-sessions 1 \
  --max-sessions-per-remote 1 \
  --max-addrs-per-share 4
curl http://127.0.0.1:18083/readyz
curl http://127.0.0.1:18083/metrics
curl -i -X POST http://127.0.0.1:18083/v1/resolve \
  -H 'Content-Type: application/json' \
  -d '{"version":1,"type":"resolve_share","request_id":"qa-invalid-hash","code_hash":"invalid"}'
```

Expected:

- `/readyz` shows the configured limits.
- `/metrics` returns Prometheus text with rendezvous counters and active
  sessions.
- the malformed resolve request returns HTTP `400`, an `invalid_request` error,
  and the matching `request_id: qa-invalid-hash`;
- normal share, resolve, close, publish, and unpublish responses retain the
  request ID sent by the client.

### Share Management Authorization

Start a normal share with `--json` against the current rendezvous server and
copy the `code_hash` from its output. Attempt to close it without the private
management token:

```sh
curl -i -X POST http://127.0.0.1:18083/v1/shares/close \
  -H 'Content-Type: application/json' \
  -d '{"version":1,"type":"close_share","request_id":"qa-unauthorized-close","code_hash":"<code-hash>"}'
```

Expected:

- `/v1/info` includes `share-management-v1`;
- the unauthorized close returns HTTP `403` and `forbidden`;
- the share still resolves and carries tunnel traffic afterwards;
- stopping the real share process removes its registration normally;
- a legacy client connected to a server that does not advertise
  `share-management-v1` can still register and close a share.

### Reverse Proxy Source Addresses

Start rendezvous with one session per forwarded client:

```sh
go run ./cmd/portp2p rendezvous --plain \
  --listen 127.0.0.1:18083 \
  --trusted-proxy 127.0.0.1 \
  --max-sessions-per-remote 1
```

Register two different shares while sending different `X-Forwarded-For`
addresses from curl. Both must succeed. A second registration from the same
forwarded address must return HTTP 429. Repeat without `--trusted-proxy`; the
forwarded header must then be ignored.

### Rendezvous Restart Recovery

Start a target, rendezvous, `share --expires 2m`, and a connector. Restart only
the rendezvous process, wait up to 35 seconds, then start a second connector
with the same code. The second connector must resolve and the original share
must still stop at its original expiry time.

Repeat with `share --publish`. The discovery listing must return after the same
refresh window with its original public code and expiry time.

### Tunnel Handshake Limits

Run a share with `--max-pending-handshakes 1 --handshake-timeout 2s`. Open an
unauthenticated libp2p tunnel stream that sends no capability frame and verify
that it is closed after roughly two seconds. Additional pending handshakes must
be rejected while the slot is occupied; normal authenticated connections must
work again immediately afterwards.

## Release Snapshot

Run a local non-publishing release snapshot. If `GPG_KEY_PATH` is not already set
to a local signing key, create a short-lived throwaway key for the snapshot:

```sh
tmpgnupg="$(mktemp -d /tmp/portp2p-gnupg.XXXXXX)"
chmod 700 "$tmpgnupg"
keyfile="/tmp/portp2p-snapshot-signing-key.asc"
GNUPGHOME="$tmpgnupg" gpg --batch --pinentry-mode loopback --passphrase '' --quick-gen-key 'portp2p snapshot <release@portp2p.local>' rsa2048 sign 1d
GNUPGHOME="$tmpgnupg" gpg --batch --armor --export-secret-keys 'portp2p snapshot <release@portp2p.local>' > "$keyfile"
export GPG_KEY_PATH="$keyfile"

goreleaser release --snapshot --clean --skip=publish
(cd dist && shasum -a 256 -c checksums.txt)
ruby -c dist/homebrew/portp2p.rb
./dist/portp2p_darwin_arm64_v8.0/portp2p version --plain
```

Expected:

- GoReleaser creates macOS/Linux tarballs, Windows zip archives, `.deb`, `.rpm`,
  `checksums.txt`, and `dist/homebrew/portp2p.rb`.
- Checksums verify.
- Homebrew formula syntax is OK.
- Snapshot binary shows injected version, commit, date, and user agent.

The tagged GitHub release workflow gets its signing key from
`LINUX_REPO_GPG_PRIVATE_KEY`; the throwaway key above is only for local snapshot
QA.
