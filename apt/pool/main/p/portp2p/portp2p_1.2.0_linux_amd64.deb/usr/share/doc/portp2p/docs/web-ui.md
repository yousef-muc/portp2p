# Local Web UI

`portp2p web` starts an embedded browser interface for the same local share,
connect, and discovery workflows as the CLI. The HTML, CSS, and JavaScript are
part of the `portp2p` binary; no separate frontend service or installation is
required.

## Start The Interface

With a rendezvous URL already configured:

```sh
portp2p web
```

Or select it for this process:

```sh
portp2p web --server https://relay.example.com
```

Open the printed URL, normally `http://127.0.0.1:4173`. Use another local port
when needed:

```sh
portp2p web --listen 127.0.0.1:4174
```

The `ui` command is an alias for `web`.

The interface starts in dark mode. The icon in the top bar switches between
dark and light mode, and the selected theme is stored only in that browser's
local storage.

## Available Workflows

The local interface can:

- create a private share for one localhost port;
- explicitly publish a public or invitation-only discovery listing;
- select direct access or owner approval independently from visibility;
- assign a stable service key for signed identity and controlled access;
- publish or unpublish an active private share;
- connect a private or public code to a local port;
- search and filter current public discovery listings;
- open private invitations and request access to protected listings;
- approve or deny requests for active shares;
- retain pending requester tokens in browser session storage;
- list and stop sessions started by this Web UI process;
- override the relay multiaddr for a share or connection;
- change the rendezvous URL while no sessions are active.

Closing the browser tab does not stop sessions. Keep the `portp2p web` process
running while they are needed, and stop it with Ctrl+C to close all sessions
cleanly.

## Shares, Visibility, And Access

A share is private by default. Its private code is shown only in the local
interface and is never added to discovery. Selecting Publish in discovery is an
explicit action. Visibility and access are then separate choices:

| Visibility | Access | Behavior |
| --- | --- | --- |
| Public search | Direct | Search result contains a connect code |
| Public search | Approval required | Search result accepts signed requests |
| Private invitation | Direct | Invitation reveals a connect code |
| Private invitation | Approval required | Invitation permits a signed request |

Direct public access remains unrestricted: anyone who finds the listing can
connect while it is online. Keep application-level authentication enabled for
sensitive services.

The optional Stable service key creates a Discovery v2 listing. Reusing that
key with the same configured identity produces the same stable service ID.
Signed listings show their stable service ID, publisher ID, and a signed badge
in sessions and search results. The badge proves continuity of a cryptographic
key, not a real-world identity or operator endorsement.
The settings dialog also shows the current public Publisher ID once the local
identity exists; hovering it reveals the configured identity path.

A separate verified badge appears only when the configured discovery server
has placed that signed Publisher ID on its operator allowlist. It represents
that server operator's assertion and is not a global portp2p endorsement.
The discovery view can restrict results to these publishers with the Verified
only checkbox. Its normal search field also accepts a stable service ID,
service key, or Publisher ID.

Approval listings never expose a public connect code. Requesters may include a
short message, and owners decide pending requests from the active session.
Approved codes are short-lived and work only with the requester identity that
signed the request.

Private listings never appear in public search or result counts. The owner
shares a separate invitation code, which recipients open in the Private
invitation section. The invitation is distinct from the normal private share
code and from approved connect codes.

The Web UI stores each private request token in that tab's browser session
storage so it can poll for approval without placing secrets in URLs. This is
local convenience state, not a server account or persistent database.

## Rendezvous, Relay, And Proxy Configuration

The Web UI uses the same configuration precedence as the CLI:

1. command-line flags such as `--server`, `--identity`, and `--proxy`;
2. `PORTP2P_*` environment variables;
3. the JSON config selected by `--config` or `PORTP2P_CONFIG`;
4. build-time defaults.

The Server dialog changes the rendezvous URL only for the running Web UI
process. Active sessions must be stopped first. An optional relay multiaddr in
the Share or Connect form overrides automatic relay discovery for that
operation. Proxy and identity configuration are intentionally inherited from
the process and are not exposed as editable browser fields.

## Local Security Boundary

The Web UI is a local operator interface, not a hosted dashboard or server
administration console. Its HTTP listener accepts only loopback addresses.
Requests are also protected by loopback Host validation, same-origin checks,
a random per-process mutation token, strict browser security headers, request
size limits, and HTTP timeouts.

Do not reverse proxy the Web UI, publish its port, tunnel it to another machine,
or bind it to a LAN or public address. The process deliberately rejects values
such as `0.0.0.0:4173`. Anyone who can control the local browser session may see
live private share codes and stop its sessions, so use the same local account
security expected for other developer tools.

The Web UI does not create a database, user account, role system, or persistent
session store. Rendezvous and relay infrastructure remain separate processes;
use `portp2p server`, `rendezvous`, or `relay` to operate them.
